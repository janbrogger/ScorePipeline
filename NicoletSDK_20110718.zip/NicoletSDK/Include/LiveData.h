#pragma once


#include "CommonDecl.h"
#include "SocketImplDR.h"
#include "TSInfo.h"
#include "Sniffer.h"
#include "SignalInfo.h"
#include "ChannelInfo.h"
#include "RecordingHelper.h"
#include "SensorInfo.h"



//Declaration
//typedef void (CLiveData::*pDataStream)(PACKET pPacket, long lcBytes);

class CSocketImplDR;

class CLiveData : public IMyDataReceiver
{
public:
   CLiveData(void);
   ~CLiveData(void);

   void ConnectToComputer(BSTR wcComputer, long lPort);
   void SetSocket(CSocketImplDR* pSocket){m_pcSocket = pSocket;};
   virtual void ReceivePacket(PACKET pPacket);
   
   

private:
   void _ViewData();
   
//   pDataStream m_cc;

private:
   CSocketImplDR* m_pcSocket;
   CGeneralDataPacket m_cData;
   CRecordingHelper m_cRecordingHelper;
   CTSInfo m_cTSInfo;
   CSensorInfo m_cSensorInfo;
   CSignalInfo m_cSignalInfo;
   FILE *m_stream;
   bool m_bNewTsInfo;
   long m_lcPacketToShow;
   NRVDATE m_nrvdateFirst;
   bool m_bStop;

};

