// Example1.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "VSyncInfo.h"
#include "EegFileWrapper.h"

bool _GetSensorsAndData(FILE *stream, CEegFileWrapper &eeg);
bool _GetEvents(FILE *stream, CEegFileWrapper &eeg);
bool _GetVideoSyncronizationInformation(FILE *stream, CEegFileWrapper &eeg);
bool _GetSleepInformation(FILE *stream, CEegFileWrapper &eeg);
bool _GetPatientInformation(FILE *stream, CEegFileWrapper &eeg);
bool _ErrorHandling(FILE *stream, _bstr_t bstrPacket);

void main()
{
   ::CoInitialize(NULL);
   try
   {
      FILE *stream;
      //The "user friendly" wrapper to the EEG files.
      CEegFileWrapper eeg; 

      if (!eeg.InitializeStorageMan())
      {
         //Register the SDK dlls
         wprintf(L"Creation of StorageMan failed\nMake sure that\n\tFileAccessSDK33.dll\n\tAddInIFSDK33.dll\n\tDataStorageSDK33.dll and\n\tXStrorageSDK33.dll\nare properly registered!\n");
         system("pause");
         ::CoUninitialize();
         exit(1);
      }
      //Open file that shows what we have read from the Test.e file
      stream = fopen(".\\out.txt", "w");
      _bstr_t bstrFile = L".\\Test.e";
      if (!eeg.Open(bstrFile, FILE_SHARE_READ | FILE_SHARE_WRITE))
      {
         wprintf(L"Could not Open File");
         return;
      }
      // Get the Events inserted into the file
      if (!_GetEvents(stream, eeg))
         return;
      if (!_GetVideoSyncronizationInformation(stream, eeg))
         return;
      // Get the Sleep Score information
      if (!_GetSleepInformation(stream, eeg))
         return;
      _GetPatientInformation(stream, eeg);
	  // Get the RAW signals and data from the file
      if (!_GetSensorsAndData(stream, eeg))
         return;

      fclose(stream);
   }
   catch (_com_error& e)
   {
      // Crack _com_error
      _bstr_t bstrSource(e.Source());
      _bstr_t bstrDescription(e.Description());
      _bstr_t bstrError(e.Error());
      _bstr_t bstrErrorMessage(e.ErrorMessage());

      wprintf(L"We got _com_error, hr = %d\n", e.Error());
      wprintf(L"Sorce; " + bstrSource + L" Desc:" + bstrDescription + L" Error:"
         + bstrError+ L" ErrorMessage:" + bstrErrorMessage + L"\n") ;

   }

   ::CoUninitialize();
}



bool _GetSensorsAndData(FILE *stream, CEegFileWrapper &eeg)
{
   CSensorInfo cSensorInfo;      //Used to get the placement of sensor, color etc.
   if (!eeg.GetSensorInfo(&cSensorInfo))
      return _ErrorHandling(stream, L"SensorInfo");

   CSignalInfo cSignal;
   if (!eeg.GetSignalInfo(&cSignal))
      return _ErrorHandling(stream, L"SignalInfo");

   long lcSensors = cSensorInfo.GetElementCount();
   long lcSignals = cSignal.GetElementCount();
   long lSegments = eeg.QuerySegmentCount();
   fwprintf(stream, L"There are %d defined signals and %d defined sensors in the file\n", lcSensors, lcSignals);


   //*****************Loop through the datasegments*************************
   for (long liDataSegment = 0; liDataSegment < lSegments; liDataSegment++)
   {
      if (liDataSegment == 0)
         fwprintf(stream,L"********** Active sensors in first segment **********\n\n");
      CTSInfo cTsInfo;
      if(!eeg.GetTSInfo(&cTsInfo, liDataSegment))
         return _ErrorHandling(stream, L"TsInfo");
      long lcActiveChannels = cTsInfo.GetElementCount(); //Number of channel that are in use in segment [liDataSegment]

      //***************Loop through the active channels for each segment*****************
      for (long liChannel = 0; liChannel < lcActiveChannels; liChannel++)
      {
         const TSINFO* pti = &cTsInfo[liChannel]; //Get information about the [liDataSegment] active channel
         double dResolution = pti->dResolution;  //The resolution, used to scale the signal microV/CM

         const SIGNALINFO* psi = cSignal.GetSignalInfoFromName(pti->szActiveSensor);
         //Channel information
         bool bBipolar = psi->bBipolar == TRUE;   //if bipolar then there is no derivation needed
         bool bAC = psi->bAC == TRUE;             //signal AC or DC

         const SENSORINFO* psei = cSensorInfo.GetSensorInfoFromName(pti->szActiveSensor);
         //Position of the sensor
         if (psei != NULL)
         {
            //double dAzimuth = psei->dX1;  The sensor coordinates 
            //double dLongitude = psei->dX2;
            if (liDataSegment == 0)
            {		
               fwprintf(stream, L"Channel %s, dResolution %2.4f, Unit %s, bBipolar: %d, bAC: %d\n", pti->szActiveSensor, 
				   dResolution, psi->szUnit, bBipolar, bAC);
            }
         }
         else
         {
            fwprintf(stream, L"Channel %s is a calculated(laplace, average, etc) channel: \n", pti->szActiveSensor);
         }
      }
      CDataPacket cData;
      //Get the duration of each segment
      double dDur = eeg.QuerySegmentDuration(liDataSegment);
      //Get the starttime of each segment
      NRVDATE nrv = eeg.QuerySegmentStartTime(liDataSegment);
      //Get the data for each segment
      if(!eeg.GetDataPacket(nrv, dDur, &cData))
         return _ErrorHandling(stream, L"GetData");

      //Check if the dataPacket matches the TsInfo information
      _ASSERT(cData.GetSerieCount() == static_cast<long>(cTsInfo.GetElementCount()));

      //**************For each dataserie or for each active sensor in segment liDataSegment***********
      for (long liDataSerie = 0; liDataSerie < cData.GetSerieCount(); liDataSerie++)
      {
         short* pData = cData[liDataSerie];
         if(liDataSerie == 0)
            if(!eeg.GetTSInfo(&cTsInfo, liDataSerie))
               return _ErrorHandling(stream, L"TsInfo");
         double dResolution = cTsInfo[liDataSerie].dResolution;
         double dOffset = cTsInfo[liDataSerie].dOffset;
         //************************For each sample in sensor******************************
         for (long liSample = 0; liSample < cData.GetSampleCount(liDataSerie); liSample++)
         {
            // 's' is the datagram from channel 'liDataSerie' and sample 'liSample' in segment 'liDataSegment'
            short s = *pData++;
            if (liDataSerie == 0)
            {
               if (liSample == 0)
                  fwprintf(stream, L"\n********Data for the first channel in the first segment\n");
               fwprintf(stream, L"Channel: 1, Segment: %d, sample: %d, value: %5.3f: \n",liDataSegment, liSample, (double)s * dResolution + dOffset);
            }
         }
      }

   }//Memory of cData released
   return true;
}

bool _GetEvents(FILE *stream, CEegFileWrapper &eeg)
{
   // Event manipulation
   fwprintf(stream, L"\n\n\n********** Events in file **********\n\n");

   // Get The Event Types.
   // All events are of a specific event type.
   CEventTypeInfo cEventType;
   eeg.GetEventTypeInfo(&cEventType);

   for (long li = 0; li < eeg.GetEventCount(); li++)
   {
      CEventMarker cEvent;
      // Get the Event and the event type
      eeg.GetEvent(li, &cEvent);
      GUID guidID = cEvent.GetEventType();
      long lIndex = cEventType.FindEventType(guidID);
      if (lIndex > -1)
      {
         const EVENTTYPEINFO& Ev = cEventType.GetElement(lIndex);
         //to check if an event is f.ex impedance. the guidID can be used directly.
         _ASSERTE(guidID == Ev.guidEventType);

         if (Ev.guidEventType == HCEVENT_IMPEDANCE_TEST)
         {
            CImpedanceMarker cImp;
            if (!eeg.GetImpedance(&cImp, cEvent.GetUniqueGuid()))
               return _ErrorHandling(stream, L"ImpedanceMarker");

            for (long limpi = 0; limpi < (long)cImp.GetInputCount(); limpi++)
            {
               const IMPTESTEVENTINFO& info = cImp[limpi];
               fwprintf(stream, L"Impetance test, Sensor: %s\n", info.szSensor);
               // TODO
               // Display the ipendace results
            }
         }
         fwprintf(stream, L"%s\n", Ev.wcAbbrevation);
         
         
      }
   }
   return true;
}

bool _GetVideoSyncronizationInformation(FILE *stream, CEegFileWrapper &eeg)
{
   // VideoSyncronization Information
   fwprintf(stream, L"\n\n\n********** Video Synchronization Information **********\n\n");
   CVSyncInfo cVideoSyncInfo;
   if (!eeg.GetSyncInfo(&cVideoSyncInfo))
      return _ErrorHandling(stream, L"VideoSyncInfo");
   long lcSyncPoints = cVideoSyncInfo.GetElementCount();
   if (lcSyncPoints > 0)
      fwprintf(stream, L"EEG file does have video synchronization information:\n");

   for (long liSync = 0; liSync < lcSyncPoints; liSync++)
   {
      SYNCINFO sync = cVideoSyncInfo.GetElement(liSync);
      // Between two Sync Points of the same file name
      // you can use linear interpolation on both the
      // video frame number and the EEG timestamp to
      // play the video synchronized with the EEG
      fwprintf(stream, L"Video File = %s, frame number = %d\n", sync.wcFile, sync.llPos);
      fwprintf(stream, L"EEG dDate = %5.3f, EEG dFraction = %5.3f \n\n", sync.nrv.dDate, sync.nrv.dFraction);
   }
   return true;
}
bool _GetSleepInformation(FILE *stream, CEegFileWrapper &eeg)
{
   //Sleep Information
   fwprintf(stream, L"\n\n\n********** Sleep Score Information **********\n\n");
   CComQIPtr<ISleepData> pISleepData;
   HRESULT hr = eeg.m_pStorage->GetSleepData(&pISleepData);
   if (FAILED(hr))
      return _ErrorHandling(stream, L"GetSleepData");
   VARIANT_BOOL bSleepMode = VARIANT_FALSE;
   pISleepData != NULL ? pISleepData->get_bSleepMode(&bSleepMode) : bSleepMode = VARIANT_FALSE ;
   if (bSleepMode)
   {
      // Hypnogram
      long lcHypnograms = 0;
      pISleepData->GetHypnogramCount(&lcHypnograms);
      for (long liHypnogram = 0; liHypnogram < lcHypnograms; liHypnogram++)
      {
         CComBSTR bstrHypnogram;
         pISleepData->GetHypnogramNameFromIndex(liHypnogram, &bstrHypnogram);
         fwprintf(stream, L"Hypnogram Name: %s \n", bstrHypnogram);
         long lcEpochs = 0;
         pISleepData->get_lcEpochs(bstrHypnogram, &lcEpochs);
         for (long liEpoch = 0; liEpoch < lcEpochs; liEpoch++)
         {
            long lLength = 0; // Epoch length, Default is 30 seconds
            BYTE Score = 0; // The Sleep Score
            pISleepData->ReadData2(bstrHypnogram, liEpoch, &Score, &lLength);
            fwprintf(stream, L"Epoch number = %d, Sleep Score = %d, Epoch Length = %d\n", liEpoch, Score, lLength);
         }
      }
   }
   return true;
}

bool _GetPatientInformation(FILE *stream, CEegFileWrapper &eeg)
{
   // Patient Information
   CPatientInfo cPatient;
   if (!eeg.GetPatientInfo(&cPatient))
      return _ErrorHandling(stream, L"PatientInfo");
   _bstr_t bstrName;
    if (cPatient.m_bstrFirstName.length() > 0)
		bstrName += cPatient.m_bstrFirstName;
	if (cPatient.m_bstrMiddleNames.length() > 0)
		bstrName += bstrName.length() > 0 ? L" " : L"" + cPatient.m_bstrMiddleNames;
	if (cPatient.m_bstrLastName.length() > 0)
		bstrName +=  bstrName.length() > 0 ? L" " : L"" + cPatient.m_bstrLastName;
   fwprintf(stream, L"\n********* The patient name is: %s *********\n\n", (WCHAR*)bstrName);

   // Test Information
   fwprintf(stream, L"\n\n\n********** Test Information **********\n\n");
   CTestInfo cTest;
   if (!eeg.GetTestInfo(&cTest))
      return _ErrorHandling(stream, L"TestInfo");
   fwprintf(stream, L"Recording Machine: %s\n", cTest.m_bstrMachineName.length() > 0 ? (WCHAR*)cTest.m_bstrMachineName : L"");

   // Study Information
   CStudyInfo cStudy;
   if (!eeg.GetStudyInfo(&cStudy))
      return _ErrorHandling(stream, L"StudyInfo");
   if (cStudy.m_bstrStudyID.length() > 0)
   {
      fwprintf(stream, L"\n\n********* The test is registered in some database. ID: %s *********\n\n", (WCHAR*)cStudy.m_bstrStudyID);
   }
   else
   {
      fwprintf(stream, L"\n\n********* The recording was done standalone. *********\n\n");
   }

   // User Information
   CUsersInfo cUsers;
   if (!eeg.GetUsersInfo(&cUsers))
      return _ErrorHandling(stream, L"UserInfo");
   long liUser = cUsers.FindUser(cTest.m_bstrTechnicianID);
   if (liUser > -1)
   {
      fwprintf(stream, L"********** The Technicians name is: %s *********\n\n", (WCHAR*)cUsers[liUser].m_bstrName);
   }
   return true;
}

bool _ErrorHandling(FILE *stream, _bstr_t bstrPacket)
{
	_bstr_t bErrrorMsg = L"ERROR in " + bstrPacket + L" packet please contact SDK provider for support\n\n";
	wprintf(bErrrorMsg);
	system("pause");
	fwprintf(stream, bErrrorMsg);
   return false;
}



