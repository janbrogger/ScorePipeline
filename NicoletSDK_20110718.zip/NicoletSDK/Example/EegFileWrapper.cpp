// EegFileWrapper.cpp: implementation of the CEegFileWrapper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EegFileWrapper.h"
#include "FileAccess3_i.c"

#define DAY    86400.0

template <class T>
bool CInfoHelper<T>::GetStaticInfo(GUID guid, IStorageMan* pStorage, T* const pt) const
{
   CComPtr<IEegData> pEegData = NULL;
   HRESULT hr = pStorage->GetEegData(&pEegData);
   if (FAILED(hr))
      return false;

   long lSize = 0;
   hr = pEegData->QueryStaticInfoPacketSize(guid, &lSize);
   if (SUCCEEDED(hr) && lSize > 0)
   {
      PACKET pPacket = NULL;
      pPacket = new BYTE[lSize];
      HRESULT hr = pEegData->GetStaticInfoPacket(guid, lSize, pPacket);
      if (FAILED(hr))
      {
         delete[] pPacket;
         return false;
      }
      bool bret = pt->SetPacketPermanent(pPacket);
      delete [] pPacket;
      return bret;
   }
   return false;
}

template <class T>
bool CInfoHelper<T>::GetDynamicInfo(GUID guid, IStorageMan* pStorage, 
                                      long liSegment, T* const pt) const
{
   CComPtr<IEegData> pEegData = NULL;
   HRESULT hr = pStorage->GetEegData(&pEegData);
   if (FAILED(hr))
      return false;

   IEegSegments* pSegments = NULL;
   hr = pStorage->GetEegSegments(&pSegments);
   if (FAILED(hr))
      return false;

   NRVDATE nrv = {-1, -1};
   hr = pSegments->QuerySegmentStartTime2(liSegment, &nrv.dDate, &nrv.dFraction);
   if (FAILED(hr))
      return false;
   long lSize = 0;
   long lChange = 0;
   hr = pEegData->QueryLastInfoChange(guid, nrv, &lSize, &lChange);
   if (FAILED(hr))
      return false;
   if (lSize)
   {  
      PACKET pPacket;
      pPacket = new BYTE[lSize];
      HRESULT hr = pEegData->GetInfoPacket2(lChange, lSize, pPacket);
      if (FAILED(hr))
      {
         delete[] pPacket;
         return false;
      }
      bool bret = pt->SetPacketPermanent(pPacket);
      delete [] pPacket;
      return bret;
   }
   return false;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CEegFileWrapper::CEegFileWrapper()
{
}

CEegFileWrapper::~CEegFileWrapper()
{
   m_pStorage->Close();
}

bool CEegFileWrapper::InitializeStorageMan()
{
   HRESULT hr = CoCreateInstance(CLSID_StorageMan, NULL, CLSCTX_INPROC_SERVER, IID_IStorageMan, (void **) &m_pStorage);
   if (FAILED(hr))
   {
      _ASSERT(false);
   }
   return hr == S_OK;
}

bool CEegFileWrapper::Open(BSTR bstrFile, unsigned long ulMask)
{
   short bReadOnly = true, bOnline = false;
   return m_pStorage->Open(bstrFile, ulMask, bOnline, bReadOnly) == S_OK;
}

bool CEegFileWrapper::Close()
{
   return m_pStorage->Close() == S_OK;
}

bool CEegFileWrapper::GetSignalInfo(CSignalInfo* const psi) const
{
   CInfoHelper<CSignalInfo> cInfo;
   return cInfo.GetStaticInfo(SIGNALINFOGUID, m_pStorage, psi);
}

bool CEegFileWrapper::GetTSInfo(CTSInfo* const ptsi, long liSegment) const
{
   CInfoHelper<CTSInfo> cInfo;
   return cInfo.GetDynamicInfo(TSGUID, m_pStorage, liSegment, ptsi);
}

bool CEegFileWrapper::GetSensorInfo(CSensorInfo* const psei) const
{
   CInfoHelper<CSensorInfo> cInfo;
   return cInfo.GetStaticInfo(SENSORINFOGUID, m_pStorage, psei);
}

bool CEegFileWrapper::GetSyncInfo(CVSyncInfo* const pSyncInfo) const
{
   CInfoHelper<CVSyncInfo> cInfo;
   return cInfo.GetStaticInfo(VIDEOSYNCGUID, m_pStorage, pSyncInfo);
}


bool CEegFileWrapper::GetPatientInfo(CPatientInfo* const ppi) const
{
   CInfoHelper<CPatientInfo> cInfo;
   return cInfo.GetStaticInfo(PATIENTINFOGUID, m_pStorage, ppi);
}

bool CEegFileWrapper::GetTestInfo(CTestInfo* const pti) const
{
   CInfoHelper<CTestInfo> cInfo;
   return cInfo.GetStaticInfo(TESTINFOGUID, m_pStorage, pti);
}

bool CEegFileWrapper::GetStudyInfo(CStudyInfo* const psti) const
{
   CInfoHelper<CStudyInfo> cInfo;
   return cInfo.GetStaticInfo(STUDYINFOGUID, m_pStorage, psti);
}

bool CEegFileWrapper::GetUsersInfo(CUsersInfo* const pui) const
{
   CInfoHelper<CUsersInfo> cInfo;
   return cInfo.GetStaticInfo(USERSINFOGUID, m_pStorage, pui);
}

long CEegFileWrapper::QuerySegmentCount() const
{
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   if (FAILED(hr))
      return 0;
   long lcSegments = 0;
   pIEegSegments->get_lcSegments(&lcSegments);
   return lcSegments;
}

double CEegFileWrapper::QuerySegmentDuration(long liSegment) const
{
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   if (FAILED(hr))
      return 0.0;
   double dDuration = 0.0;
   pIEegSegments->QuerySegmentDuration(liSegment, &dDuration);
   return dDuration;
}

NRVDATE CEegFileWrapper::QuerySegmentStartTime(long liSegment) const
{
   NRVDATE nrv = {-1, -1};
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   if (FAILED(hr))
      return nrv;
   pIEegSegments->QuerySegmentStartTime2(liSegment, &nrv.dDate, &nrv.dFraction);   
   return nrv;
}

NRVDATE CEegFileWrapper::QuerySegmentEndTime(long liSegment) const
{
   NRVDATE nrv = {-1, -1};
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   if (FAILED(hr))
      return nrv;
   pIEegSegments->QuerySegmentEndTime2(liSegment, &nrv.dDate, &nrv.dFraction); 
   return nrv;
}

long CEegFileWrapper::QueryNrvDateToSegment(const NRVDATE& nrv) const
{
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   long liSegment = 0;
   VARIANT_BOOL bInSegment;
   pIEegSegments->QueryLastSegment(nrv.dDate, nrv.dFraction, &liSegment, &bInSegment);
   if (!bInSegment)
      return -1;
   else
      return liSegment;
}

bool CEegFileWrapper::QueryRecSecToNrvDate(const double dRecSec, NRVDATE& nrv) const
{
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   return pIEegSegments->RecSec2NrvDate(dRecSec, &nrv.dDate, &nrv.dFraction) == S_OK;
}

bool CEegFileWrapper::QueryNrvDateToRecSec(const NRVDATE& nrv, double* pdRecSec) const
{
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   return pIEegSegments->NrvDate2RecSec(nrv.dDate, nrv.dFraction, pdRecSec) == S_OK;
}
   

bool CEegFileWrapper::_CheckSegmentConstraints(const NRVDATE& nrv, double dDur) const
{
   CComPtr<IEegSegments> pIEegSegments;
   HRESULT hr = m_pStorage->GetEegSegments(&pIEegSegments);
   if (FAILED(hr))
      return false;
   long liSegment = 0;
   VARIANT_BOOL bInSegment;
   pIEegSegments->QueryLastSegment(nrv.dDate, nrv.dFraction, &liSegment, &bInSegment);
   if (!bInSegment)
      return false;
   NRVDATE ndtEnd = QuerySegmentEndTime(liSegment);
   NRVDATE ndtNow(nrv);
   double ndts = floor( (ndtEnd.dDate - ndtNow.dDate) * DAY + 0.5);
   return dDur <= ndts;
}

bool CEegFileWrapper::GetDataPacket(const NRVDATE& nrv, double dDur, CDataPacket* const pData) const
{
   if (!_CheckSegmentConstraints(nrv, dDur))
      return false;
   CComPtr<IEegData> pEegData = NULL;
   HRESULT hr = m_pStorage->GetEegData(&pEegData);
   if (FAILED(hr))
      return false;

   long lChannels = 0;
   pEegData->GetChannelCount(nrv, &lChannels);
   long* plcSamples = new long[lChannels];
   long lcSamples = 0;

   for (long lci = 0; lci < lChannels; lci++)
   {
      pEegData->GetSampleCount(lci, nrv, dDur, &lcSamples);
      plcSamples[lci] = lcSamples;
   }
   pData->PreparePacket(lChannels, plcSamples);
   pEegData->GetDataPacket(nrv, dDur, (long)pData->GetSize(), pData->GetPacket());
   delete[] plcSamples;
   plcSamples = NULL;

   return true;
}

long CEegFileWrapper::GetEventCount() const
{
   CEventMarker cBaseEvent;
   CComPtr<IEventWrapper> pIEventWrapper;
   HRESULT hr = m_pStorage->GetEventWrapper(&pIEventWrapper);
   if (FAILED(hr))
      return 0;
   long lcEvents = 0;
   pIEventWrapper->QueryCount(&lcEvents);  
   return lcEvents;
}

bool CEegFileWrapper::GetEvent(long liEvent, CEventMarker* const pEvent) const
{
   PACKET pPacket = NULL;
   CComPtr<IEventWrapper> pIEventWrapper;
   HRESULT hr = m_pStorage->GetEventWrapper(&pIEventWrapper);
   if (FAILED(hr))
      return false;
   hr = pIEventWrapper->GetEvent(liEvent, &pPacket);      
   if (FAILED(hr))
      return false;
   
   return pEvent->SetPacket(pPacket);
}

bool CEegFileWrapper::GetEventTypeInfo(CEventTypeInfo* const peti) const
{
   CInfoHelper<CEventTypeInfo> cInfo;
   return cInfo.GetStaticInfo(EVENTTYPEINFOGUID, m_pStorage, peti);
}

bool CEegFileWrapper::GetImpedance(CImpedanceMarker* const pim, const GUID& guid) const
{
   CComPtr<IEventWrapper> pIEventWrapper = NULL;
   HRESULT hr = m_pStorage->GetEventWrapper(&pIEventWrapper);
   if (FAILED(hr))
      return false;
   PACKET pPacket = NULL;
   pIEventWrapper->GetEventFromGUID(guid, &pPacket);
   return pim->SetPacketPermanent(pPacket);
}
