#include "StdAfx.h"
#include "livedata.h"

#define PACKET_TO_SHOW 10

CLiveData::CLiveData() : m_bStop(false), m_bNewTsInfo(false)
{
   m_stream = fopen(".\\outData.txt", "w");
   m_lcPacketToShow = 0;
   m_nrvdateFirst.dDate = -1;
}

CLiveData::~CLiveData()
{
   fclose(m_stream);
}

void CLiveData::ConnectToComputer(BSTR wcComputer, long lPort)
{
   m_pcSocket->SetReceiver(this);
   m_pcSocket->ConnectToSocket(wcComputer, lPort);
}

void CLiveData::ReceivePacket(PACKET pPacket)
{

   bool bChanged = false;
   //*************************************************************************************
   //The m_cTSInfo, m_cSensorInfo, m_cRecordingHelper, m_cSignalInfo packets should all
   //arrive before the first m_cData packet. There is no check for that here
   //but it should never happen
   //***********************************************************************************
   if (m_cData.SetPacket(pPacket))
   {
      _ASSERTE(m_cData.GetSerieCount() > 0);
      _ASSERTE(m_cSensorInfo.IsAllocated());
      _ASSERTE(m_cTSInfo.IsAllocated());
      _ASSERTE(m_cSignalInfo.IsAllocated());
      if (m_nrvdateFirst.dDate < 0)
      {
         m_nrvdateFirst = m_cData.GetTimeStamp().nrvStamp;
      }
     
      if (m_lcPacketToShow < PACKET_TO_SHOW)
      {
         m_stream = fopen(".\\outData.txt", "a");
         _ViewData();
         fclose(m_stream);
         m_lcPacketToShow++;
      }
      else
      {
         if (!m_bStop)
         {
            ::MessageBox(NULL, _T("Data has been written to file you can close the Application know\n"), L"OK", MB_OK);
            m_bStop = true;
         }
      }
   }
   if (m_cTSInfo.SetPacketPermanent(pPacket))
   {
      long lcChannels = m_cTSInfo.GetElementCount();
      _ASSERTE(lcChannels > 0);
      m_bNewTsInfo = true;
   }
   if (m_cSignalInfo.SetPacketPermanent(pPacket))
   {
      long lcSignals = m_cSignalInfo.GetElementCount();
      _ASSERTE(lcSignals > 0);
   }
   if (m_cSensorInfo.SetPacketPermanent(pPacket))
   {
      long lcSensors = m_cSensorInfo.GetElementCount();
      _ASSERTE(lcSensors > 0);
   }
   if (m_cRecordingHelper.SetPacket(pPacket))
   {
       bool bIsRunning = m_cRecordingHelper.IsRunning();
   }
   ULONG ul = static_cast<ULONG>(GETPACKETSIZE(pPacket));


}

void CLiveData::_ViewData()
{
   if (m_lcPacketToShow == 0)
   {
      CString cstrServerComputer = L"", cstrClientComputer;
      UINT uiServerPort = 0, uiClientPort;
      m_pcSocket->GetSockName(cstrClientComputer, uiClientPort);
      m_pcSocket->GetPeerName(cstrServerComputer, uiServerPort);
      fwprintf(m_stream, L"*************Connecting from Computer: %s and Port: %d****************\n",cstrClientComputer,uiClientPort);
      fwprintf(m_stream, L"*************Connection to Computer: %s and Port: %d succeeded**********\n First datapacket has arrived\n\n",cstrServerComputer,uiServerPort);
   }
   long lcSensors = m_cSensorInfo.GetElementCount();
   long lcSignals = m_cSignalInfo.GetElementCount();
   long lSegments = 1; 

   if (m_bNewTsInfo)
      fwprintf(m_stream, L"\n\nNew TSInfo (montage) packet with %d Channels, there are %d defined signals and %d defined sensors in the file\n",m_cTSInfo.GetElementCount(), lcSensors, lcSignals);

   long liDataSegment = 0;
   long lcActiveChannels = m_cTSInfo.GetElementCount(); //Number of channel that are in use in segment [liDataSegment]

   //***************Loop through the active channels for each segment*****************
   if (m_bNewTsInfo)
   {
      for (long liChannel = 0; liChannel < lcActiveChannels; liChannel++)
      {
         const TSINFO* pti = &m_cTSInfo[liChannel]; //Get information about the [liDataSegment] active channel
         double dResolution = pti->dResolution;  //The resolution, used to scale the signal microV/CM

         const SIGNALINFO* psi = m_cSignalInfo.GetSignalInfoFromName(pti->szActiveSensor);
         bool bBipolar = false;   //if bipolar then there is no derivation needed
         bool bAC = false;             //signal AC or DC
         if (psi !=NULL)
         {
            //Channel information
            bBipolar = psi->bBipolar == TRUE;   //if bipolar then there is no derivation needed
            bAC = psi->bAC == TRUE;             //signal AC or DC
         }

         const SENSORINFO* psei = m_cSensorInfo.GetSensorInfoFromName(pti->szActiveSensor);
         //Position of the sensor
         if (psei != NULL)
         {
            //double dAzimuth = psei->dX1;  The sensor coordinates 
            //double dLongitude = psei->dX2;
            if (liDataSegment == 0 && m_bNewTsInfo)
            {		
               fwprintf(m_stream, L"Channel %s, dResolution %2.4f, Unit %s, bBipolar: %d, bAC: %d\n", pti->szActiveSensor, 
                  dResolution, psi->szUnit, bBipolar, bAC);
            }
         }
         else if (m_bNewTsInfo)
         {
            fwprintf(m_stream, L"Channel %s is a calculated(laplace, average, etc) channel: \n", pti->szActiveSensor);
         }
      }
   }

   ////Get the duration of first segment
   double dStartTimeSec = 0, dSecsIntoRec = 0;
   dStartTimeSec = NRVDATE2SECS(m_nrvdateFirst);
   dSecsIntoRec = NRVDATE2SECS(m_cData.GetTimeStamp().nrvStamp);
   double dRecSec = dSecsIntoRec - dStartTimeSec;
   ////Get the starttime of each segment

   //Check if the dataPacket matches the TsInfo information
   _ASSERT(m_cData.GetSerieCount() == static_cast<long>(m_cTSInfo.GetElementCount()));

   //**************For each dataserie or for each active sensor in segment liDataSegment***********
   for (long liDataSerie = 0; liDataSerie < m_cData.GetSerieCount(); liDataSerie++)
   {
      short* pData = m_cData[liDataSerie];


      double dResolution = m_cTSInfo[liDataSerie].dResolution;
      double dOffset = m_cTSInfo[liDataSerie].dOffset;

      //************************For each sample in sensor******************************
      for (long liSample = 0; liSample < m_cData.GetSampleCount(liDataSerie); liSample++)
      {
         // 's' is the datagram from channel 'liDataSerie' and sample 'liSample' in segment 'liDataSegment'
         short s = *pData++;
         if (liDataSerie < 3)
         {
            if (liSample == 0)
            {
               fwprintf(m_stream, L"\n********Data for the %s sensors, segment: %d, datapacket nr: %d, samples in packet: %d, Recsec %0.4f\n", 
                  m_cTSInfo[liDataSerie].szLabel, liDataSegment, m_lcPacketToShow, m_cData.GetMaxSampleCount(), dRecSec);
            }
            fwprintf(m_stream, L"Sample: %d, value: %5.3f: \n",liSample, (double)s * dResolution + dOffset);
         }
      }
   }


   m_bNewTsInfo = false;

}



