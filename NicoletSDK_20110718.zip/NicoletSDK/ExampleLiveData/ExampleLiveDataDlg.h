// ExampleLiveDataDlg.h : header file
//

#pragma once
#include "SocketImplDR.h"

// CExampleLiveDataDlg dialog
class CExampleLiveDataDlg : public CDialog
{
   
// Construction
public:
	CExampleLiveDataDlg(CWnd* pParent = NULL);	// standard constructor
   
   ~CExampleLiveDataDlg();

// Dialog Data
	enum { IDD = IDD_EXAMPLELIVEDATA_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
   afx_msg void OnBnClickedButtonConnect();
   afx_msg void OnEnKillfocusEditComputer();

private:
   CEdit m_editComputerToConnect;
   CString m_cstrComputer;
   CSocketImplDR m_dr;
   CLiveData m_clive;
};
