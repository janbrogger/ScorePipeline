%NICGETEVENTS  Get all the events of the EventTypeID and return there
%startDate
%NicGetEvents(NicSt, EventTypeID)
%
%EventTypeID:  An array [n,1]  of EventTypeIDs
%
%Return
%vDate: An array of Event start dates [m,1] corresponding to EventTypeIDs

function [vDate] = NicGetEvents(NicSt, EventTypeID)
    n = NicSt.Events;
    cEvents = n.cEvents;
    ef = zeros(cEvents,1);
    for i=1:max(size(EventTypeID))
        a = (n.vEventTypeID == EventTypeID(i));
        ef = (a > ef) + ef;
    end
    ef = (ef > 0);
    vDate = n.vnumStartDate(ef);