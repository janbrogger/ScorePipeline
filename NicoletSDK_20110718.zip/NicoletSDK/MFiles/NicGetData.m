%NICGETDATA  Get the EEG data from the file previously opened
%   NicGetData(NicStruct, dStartTime, dDuration, vSelCh)
%
%   NicStruct:  The structure returned when NicOpen was called
%   dStartTime: The Start time of data to get, use datenum to convert date strings 
%   dDuration:  Duration in Recorded seconds
%   vSelCh:     Can be [] to get all channels, otherwice vektor of
%                   channels to get
%   
%   NOTE- To at one sec to dStartTime:  
%       dStartTime = dStartTime + 1/(24 *60 * 60)
function [mSamples, iSegment] = NicGetData(NicStruct, dStartTime, dDuration, vSelCh)

    segdur = NicStruct.vSegmentDuration;
    segstart = NicStruct.vSegmentStartTime;
    
    [iSegment] = calllib('mat1','GetSegment', dStartTime);  %Zero based iSegment
    iSegment = iSegment + 1;
     dMaxSampingrate = max(NicStruct.mSamplingRate(iSegment,:));
     cMaxSamples = dDuration * dMaxSampingrate;
     cChannels = NicStruct.vcChannels(iSegment);  %Number of channels in segment
     mSamples = zeros(cChannels, cMaxSamples);
    
    lDay = 24 *60 * 60;
    dFirstDur = floor((dStartTime - segstart(iSegment)) * lDay + 0.5); %convert to seconds
    dReadDur = segdur (iSegment) - dFirstDur;
    dDurLeft = dDuration - dReadDur;
    if (dDurLeft < 0)
        dReadDur = dDuration;
    end
    dDuration = dDuration - dReadDur;
    
        
    iRead = 1;
    while (dReadDur > 0)
        cReadSamples = dReadDur * dMaxSampingrate;
        vSamples = zeros(1,cReadSamples * cChannels);
        [ierr, vSamples] = calllib('mat1','GetData2',dStartTime, dReadDur, vSamples);
        iTotEnd = iRead + cReadSamples - 1;
        for i = 1:cChannels,
            isegmentstart = (i - 1)* cReadSamples + 1;
            isegmentend = isegmentstart + cReadSamples - 1;
            mSamples(i,iRead:iTotEnd) = vSamples(isegmentstart:isegmentend)';
        end
        iRead = iRead + iTotEnd;
        if (dDuration > 0)
            iSegment = iSegment + 1;
            dStartTime = segstart(iSegment);
            if (segdur(iSegment) > dDuration)
                dReadDur = dDuration;
            else
                dReadDur = segdur(iSegment);
            end
            dDuration = dDuration - dReadDur;
        else
            dReadDur = 0;
        end
    end
     
    if (size(vSelCh) > 0)
       mSamples = mSamples(vSelCh,:);
    end

