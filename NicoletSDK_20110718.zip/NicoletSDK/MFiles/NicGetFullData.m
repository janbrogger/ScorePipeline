%NICGETFULLDATA  Get the EEG data from the file previously opened
%   NicGetFullData(NicStruct, iSegment, vChannels)
%
%   NicStruct:  The structure returned when NicOpen was called
%   iSegment:   The segment to retreeve data from
%   vSelCh:     Can be [] to get all channels, otherwice vektor of
%                   channels to get
%   
function [mSamples] = NicGetFullData(NicStruct, iSegment, vSelCh)

    %Assume all samples have same length
     vcSamples = NicStruct.mcSamples(iSegment,:); %Number of samples per channel in segment iSegment
     cChannels = NicStruct.vcChannels(iSegment);  %Number of channels in segment
    
    cMaxSamples = max(vcSamples);
    vSamples = zeros(1,cMaxSamples * cChannels);
    [ierr, vSamples] = calllib('mat1','GetData',iSegment - 1, vSamples);
    mSamples = zeros(cChannels, cMaxSamples);
    
    for i = 1:cChannels,
        isegmentstart = (i - 1)* cMaxSamples + 1;
        isegmentend = isegmentstart + cMaxSamples - 1;
        mSamples(i,:) = vSamples(isegmentstart:isegmentend)';
    end
    if (size(vSelCh) > 0)
       mSamples = mSamples(vSelCh,:);
    end

