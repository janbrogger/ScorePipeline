%NICCLOSE Closes the MatlabSDK library handle
%         This must be done prior to opening a new file

function [] = NicClose()
%NicClose Unloads the file

if (libisloaded('mat1'))
    [ierr] = calllib('mat1','Close');
    unloadlibrary mat1
end
