%NICSHOWEVENTS Plots the events in a userfriendly way
%NicShowEvents(NicSt)

function [a] = NicShowEvents(NicSt)
n = NicSt.Events;
a = cell(n.cEvents,1);
for i = 1:n.cEvents
    a{i} = sprintf('ID: %d, Date: %s, Abbr: %16s, Dur: %2d', ...
    n.vEventTypeID(i), n.vstrStartDate(i,13:20), n.vAbbrevation{i}, n.vDuration(i));
end

