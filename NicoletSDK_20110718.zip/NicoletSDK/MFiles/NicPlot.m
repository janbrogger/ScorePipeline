%NICPLOT   Plot the EEG data
%   NicPlot(NicSt, data, DispDur)
%   NicSt:  The Nic.Structure  see NicOpen
%   data: The data to plot
%   DispDur: The duration to plot
%

function [] = NicPlot(NicSt, data, DispDur)

close all;
figure(1)
rmax = size(data,1);
dMaxSampingrate = max(NicSt.mSamplingRate(1,:));
xmax = dMaxSampingrate * DispDur;
datamax = max(max(data))/1.5;
vaxis = [0 xmax -datamax datamax];
if (rmax > 10)
    rmax = 10;
end

for k = 1:rmax
    subplot (rmax,1,k), plot(data(k,1:xmax)), axis([vaxis]);
end
