%NICOPEN,   Loads the MatlabSDK.dll and get the strfile
%NicOpen(strFile)
%
% strFile:  Name of the file to open
%
% Return:
%   NicSt:  Structur with fileinformation
%********************************************************************
%     NicSt.vSegmentDuration      %Duration of each segment in seconds
%     NicSt.vSegmentStartTime     %StartDate of each segment
%     NicSt.vSegmentStartTimestr  %StartDate in text
%     NicSt.vcChannels            %Number of channels in each segment
%     NicSt.mSamplingRate         %Sampling rate of each channel each segment
%     NicSt.mcSamples             %Sample count for each channel each segment
%     NicSt.mcChannelNames        %Name of each channel each segment

function [NicSt] = NicOpen(strFile)


if (libisloaded('mat1'))
    NicClose();
end
%REMEMBER to set MFiles directory into path "addpath ../MatlabSDK/MFiles"  
%othervice the loadlibrary will not work
loadlibrary MatlabSDK MatlabSDK alias mat1

[mi, mfilen, cSegments] = ...
    calllib('mat1','OpenEx', strFile, zeros(1));
NicSt.cSegments = cSegments;

[mi, vSegDuration, vSegStart] = ...
    calllib('mat1','GetSegmentTime',zeros(1,cSegments),zeros(1,cSegments));
NicSt.vSegmentDuration = vSegDuration;
NicSt.vSegmentStartTime = vSegStart;
NicSt.vSegmentStartTimestr = datestr(NicSt.vSegmentStartTime);

vcChannels = zeros(cSegments,1);

%Get Data for segment iSegment
iSegment = 0;
chName = '                                ';
for i=1:cSegments
    [vcChannels(i)] = calllib('mat1','GetChannelCount',iSegment);
end

NicSt.vcChannels = vcChannels;

MaxChannel = max(vcChannels);
mSamplingRate = zeros(cSegments, MaxChannel);
mcSamples = zeros(cSegments, MaxChannel);
mcChannelNames= zeros(cSegments, MaxChannel);

for iSegment=1:cSegments
    [ierr, dvSamplingRate, vcSamples] = ...
        calllib('mat1','GetSegmentInf',zeros(1), zeros(1, vcChannels(i)),zeros(1, vcChannels(i)));
    mSamplingRate(iSegment,:) = dvSamplingRate';
    mcSamples(iSegment,:) = vcSamples';
end

NicSt.mSamplingRate = mSamplingRate;
NicSt.mcSamples = mcSamples;

chName = '                                 ';
mcChannelNames = cell(cSegments, MaxChannel);

for iSegment=1:cSegments
    %Assume all samples have same length
    for iChannel = 1:vcChannels(iSegment),
        [ierr, mcChannelNames{iSegment, iChannel}] = calllib('mat1','GetChannelInf', iSegment - 1, iChannel - 1, chName);
    end
end
NicSt.mcChannelNames = mcChannelNames;

%GetEvents
[ierr cEvents] = calllib('mat1','GetEventCount',zeros(1));
vstrAbbrevation = cell(cEvents,1);
vstrDescription = cell(cEvents,1);
vstrText = cell(cEvents,1);
vEventTypeID = zeros(cEvents,1);
vDuration = zeros(cEvents,1);
vStartDate = zeros(cEvents,1);
for iEvent=1:cEvents
    [ierr, vEventTypeID(iEvent), vstrDescription{iEvent}, vstrAbbrevation{iEvent}, ...
        vstrText{iEvent}, vDuration(iEvent), vStartDate(iEvent)] ...
        = calllib('mat1','GetEvents',iEvent - 1, zeros(1), chName, chName, chName, zeros(1), zeros(1));
end
EventSt.cEvents = cEvents;
EventSt.vEventTypeID = vEventTypeID;
EventSt.vAbbrevation = vstrAbbrevation;
EventSt.vDescription = vstrDescription;
EventSt.vText = vstrText;
EventSt.vDuration = vDuration;
EventSt.vnumStartDate = vStartDate;
EventSt.vstrStartDate = datestr(vStartDate);
NicSt.Events = EventSt;





