function res = fieldnames(this);

    res = fieldnames(this(1).EEG);
